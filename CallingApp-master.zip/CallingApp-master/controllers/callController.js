module.exports.startCall=(req,res)=>{
    res.send("Call started...")
}

module.exports.showDefault=(req,res)=>{
    res.send("Specify an endpoint");
}
export { default as PeopleStore } from "./PeopleStore";
export { default as TalkStore } from "./TalkStore";
export { default as CategoryStore } from "./CategoryStore";